<!------
 *PHARMACY REGISTRATION ACTION FORM
 *Features:Server side validation,session
 *Author:Harilekshmi K
 *-->
 <link href="css/style.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<?php
    
    require "../config.php";
	include "../header.php";
	$connection = new PDO($dsn, $username, $password, $options);
	
	session_start();
   //validation
    echo $pharmacy_name=$_POST['name'];
	$pharmacy_license_no=$_POST['lnumber'];
    $drugs_category=$_POST['category'];
	$location=$_POST['location'];
	$pharmacy_owner_name=$_POST['oname'];
    $email=$_POST['email'];
    $gender=$_POST['gender'];
    $address=$_POST['address'];
    $phone=$_POST['phn'];
    $uname=$_POST['uname'];
    $pass=$_POST['pswd'];
    $cpass=$_POST['cpswd'];
	$_SESSION['namee']=$uname;
	//$_SESSION['email']=$email;
	
	if($_SESSION['namee']){

	echo $_SESSION['namee'];
        }
	
	// Name validation
	$flag=0;              
        if(preg_match("/^[a-zA-Z -]+$/", $pharmacy_name) === 0)     //First Name
		    {
			   echo " <br>Name is not valid";
			   $flag++;
		    }
	//License Validation
			 if($pharmacy_license_no=="")
		   {
			   echo "Enter a valid license";
			   $flag++;
		   }
	//location Validation	
	    if($location=="")
		   {
			   echo "Enter a valid location";
			   $flag++;
		   }
     //Owner name Validation
		    if($pharmacy_owner_name=="")
		   {
			   echo "Enter a valid owner name";
			   $flag++;
		   }
	//Email Validation
		if (filter_var($email, FILTER_VALIDATE_EMAIL))
		    {
               // echo("$email is a valid email address");
            }
		else 
		    {
               echo("<br> $email is not a valid email address");
			    $flag++;
			}
	//Gender Validation
	    if(empty($gender))
		   {
              echo "Select your gender";
			  $flag++;
           }
	 
	    if($address=="")
		   {
			   echo "Enter a valid address";
			   $flag++;
		   }
		 if($phone=="")
			{
				echo "not valid phone";
              
            }
	 //Username Validation		
		if(preg_match("/^[a-zA-Z -]+$/", $uname) === 0)     
		    {
			   echo " <br>User Name is not valid";
			   $flag++;
		    }
	//Password Validation
		if (strlen($pass) <= '6') 
		    {
                echo "Your Password Must Contain At Least 6 Characters!";
				$flag++;
            }
        elseif(!preg_match("#[0-9]+#",$pass)) 
		    {
                echo "Your Password Must Contain At Least 1 Number!";
				$flag++;
            }
        elseif(!preg_match("#[A-Z]+#",$pass)) 
		    {
                echo "Your Password Must Contain At Least 1 Capital Letter!";
				$flag++;
            }
        elseif(!preg_match("#[a-z]+#",$pass)) 
		    {
                echo "Your Password Must Contain At Least 1 Lowercase Letter!";
				$flag++;
            }
        if($pass!=$cpass)
			{
				echo "Password Mismatch!";
				$flag++;
			}
				
		//Insertion
		try{
		if($flag<1)
		{
			$sel = "Select * from pharmacy where email='$email'";
			$statement = $connection->prepare($sel);
            $statement->execute();
            $result = $statement->fetchAll();
			if ($result && $statement->rowCount() > 0) {
				echo "Email already Exist";
				echo "<a href='parent.php'>Try again</a>";
				
				
			}
			else
			{
			$sel = "Select * from pharmacy where mobile='$phone'";
			$statement = $connection->prepare($sel);
            $statement->execute();
            $result = $statement->fetchAll();
			if ($result && $statement->rowCount() > 0) {
				echo "Phone already Exist";
				echo "<a href='pharmacy.php'>Try again</a>";
			}
			else
			{
			
		$sql="INSERT INTO `pharmacy`(`pharmacy_name`, `pharmacy_license_no`, `drugs_category`, `location`, `pharmacy_owner_name`, `email`, `gender`, `mobile`, `address`, `username`, `password`) VALUES ('$pharmacy_name','$pharmacy_license_no', '$drugs_category','$location','$pharmacy_owner_name','$email','$gender','$address',
			'$phone','$uname','$pass')";
			$connection->exec($sql);
			//header( "Location:pharm_action.php" );
			
           }
		}}}
	catch(PDOException $e)
    {
        echo $sql . "<br>" . $e->getMessage();
    }
	include "../footer.php";
?>