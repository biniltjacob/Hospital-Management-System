<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<?php 
    /* Dashboard for pharmacy
	 * Features:session
	 * Authors: Harilekshmi k
	 *
	 */
	  require "../config.php";
      include "../header.php";
      
	  session_start();
	 
	  if($_SESSION["namee"]) 
	              {
					 $_SESSION["namee"]; 
 
	               }
	$connection = new PDO($dsn, $username, $password, $options);
?>

<!--sidebar start-->

<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
		<?php
		if( $_SESSION['type_id']) 
	               {
					   ?>
        <div class="leftside-navigation" tabindex="5000" style="overflow: hidden; outline: none;">
         <center>   
			<?php 
                $user=$_SESSION["namee"];
				$img = $connection->query("select gender from pharmacy where username='$user'")->fetchColumn();
                if( $img=="male"){?>
						   <img src="../img/drm.png" class="prfl">
					  <?php } else{
						  ?>
						   <img src="../img/drf.png" class="prfl">
					  <?php }  
	          //  $lic = $connection->query("select license from doctors where user_name='$user'")->fetchColumn(); 
	            $phr= $connection->query("select pharmacy_id,pharmacy_license_no from pharmacy where username='$user'")->fetchColumn(); 
                $phrl= $connection->query("select pharmacy_license_no from pharmacy where username='$user'")->fetchColumn(); 
			    
				echo   "<h4>".$_SESSION["namee"]."</h4>"; 

				//echo "<h4>  ".$_row["phr"]."<h4>"; 
				
				//echo "<h4> license No.: ".$phrl";<h4>"; 
				echo "<h1>pharmacy Id: ". $phr;
		       for($i=1;$i<=$phr;$i++){echo "<font color='black'>😊</font>";}
				echo "<h1>"; 
				
		    ?>
			</center>
			<ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="pharmacy_dashboard.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sub-menu dcjq-parent-li">
                    <a href="pharmacy_dashboard.php" class="dcjq-parent">
                        
                        <span>Review</span>
                    </a>
                    
                </li>
                
                <li>
                    <a href="../logout.php">
                        
                        <span>Logout Page</span>
                    </a>
                </li>
            </ul>            </div>
        <!-- sidebar menu end-->
</aside>		
		
		
		<!--main content start-->
<section id="main-content">
	
	<div class="row">
	<div class="col"><center>
	<p><a href="pharmacy_profile_edit.php"><img src="../img/edit.png"></a><br><br>Edit Profile</p>
	</center></div></div>
	
	
	</section>

<!--<marquee direction="right"> <img src="../img/santa.gif"></marquee>-->
<?php 
    } //session close
    include "../footer.php";
	?>