<div class="ft">
<h1>Welcome to Medical </h1>
<p>Our medical specialist care about you and your family.</p>

</div>

</body>
</html>
