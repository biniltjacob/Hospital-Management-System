<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Appointment</title>

	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="style.css">
</head>

<body class="bi">

<div class="menubar">
<ul>
<li><a href="login.php">Home</a></li>
<li><a href="about.php">About Us</a>
<li><a href="login.php">Login</a></li>

<div class="submenu" >
<ul>
<li><a href="#">Vision</a></li>
<li><a href="#">Mission</a></li>
</div></li>
<ul>
<li><a href="contact.html">Contact Us</a></li>
</ul>
</ul></div>
